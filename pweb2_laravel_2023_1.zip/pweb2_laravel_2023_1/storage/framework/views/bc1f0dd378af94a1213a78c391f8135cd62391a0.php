<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <link rel="shortcut icon" href="./public/icons/LogoPronta.svg" type="image/x-icon" />
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Editar produto | Bom Look</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700&display=swap" rel="stylesheet" />
    <script src="./src/js/slider.js" defer></script>
    <script src="./src/js/snackbar.js" defer></script>

    <script src="https://kit.fontawesome.com/b5ad8d5d3f.js" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/globalStyle.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/header.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/exprodutoedit.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/snackbar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/indexadm.css')); ?>" />
</head>

<?php
    if (!empty($produto->id)) {
        $route = route('produto.update', $produto->id);
    } else {
        $route = route('produto.store');
    }
?>

<body class="layout">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <header>
        <div class="header_adm">
            <a href="./FornecedorList.php">Fornecedores</a><br>
            <a href="./ProdutoList.php">Estoque</a><br>
            <a href="./SuporteList.php">Suporte</a><br>
            <a href="./UsuarioList.php">Usuarios</a><br>
        </div>
        <div>
            <nav>
                <div class="dropdown3">
                    <a href="adm.html"><img src="./public/icons/adm.svg"><img> </a>

                    <div class="dropdown-content3">
                        <a href="UsuarioForm.php">Cadastrar</a>
                    </div>
                </div>
            </nav> <a href="index.php">
                <img src="./public/icons/LogoPronta.svg" alt="Bom Look Logo" class="logo-adm" /></a>
        </div>
    </header>
    <div class="content">
        <div class="container">
            <img src="./public/icons/no-image.jpg" alt="" />
            <br>
            <?php
                $nome_imagem = !empty($produto->imagem) ? $produto->imagem : 'sem_imagem.jpg';
            ?>


            <br>
            <img class="img-thumbnail" src="/storage/<?php echo e($nome_imagem); ?>" width="300px" />
            <br><br>
            <input type="file" class="imgadd" name="imagem" />
            <br>

        </div>

        <form action='<?php echo e($route); ?>' method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(!empty($produto->id)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <div class="aside">
                <input type="hidden" name="id"
                    value="<?php if(!empty(old('id'))): ?> <?php echo e(old('id')); ?> <?php elseif(!empty($produto->id)): ?> <?php echo e($produto->id); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>

                <h4>Nome</h4>
                <input type="text" class="editrs_input" name="nome" placeholder="Nome produto.."
                    value="<?php if(!empty(old('nome'))): ?> <?php echo e(old('nome')); ?> <?php elseif(!empty($produto->nome)): ?> <?php echo e($produto->nome); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>

                <h4>Preço</h4>
                <input type="text" class="editrs_input" name="preco" placeholder="R$"
                    value="<?php if(!empty(old('nome'))): ?> <?php echo e(old('nome')); ?> <?php elseif(!empty($produto->preco)): ?> <?php echo e($produto->preco); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>

                <h4>Quantidade</h4>
                <input type="text" class="editrs_input" name="quantidade"
                    value="<?php if(!empty(old('nome'))): ?> <?php echo e(old('nome')); ?> <?php elseif(!empty($produto->quantidade)): ?> <?php echo e($produto->quantidade); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>

                <h4>Adicionar Tamanho</h4>
                <input type="text" class="editrs_input" name="tamanho" placeholder="P, M, G, GG"
                    value="<?php if(!empty(old('nome'))): ?> <?php echo e(old('nome')); ?> <?php elseif(!empty($produto->tamanho)): ?> <?php echo e($produto->tamanho); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>


                <h3>Descrição</h3>
                <input type="text" class="editdesc_input" name="descricao" placeholder="Descrição..."
                    value="<?php if(!empty(old('nome'))): ?> <?php echo e(old('nome')); ?> <?php elseif(!empty($produto->descricao)): ?> <?php echo e($produto->descricao); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" />
                <br>
                <br>






                <button class="btn btn-success" type="submit">
                    <i class="fa-solid fa-save"></i> Salvar
                </button>
                <a href='<?php echo e(route('produto.index')); ?>' class="btn btn-primary"><i class="fa-solid fa-arrow-left"></i>
                    Voltar</a>

            </div>

        </form>


    </div>
    <footer>
        <div>
            <i></i>
            <i></i>
            <i></i>
        </div>
        <div>
            <p>Alunos: Bernardo Augusto Picoli e João Vitor de Carvalho</p>
        </div>
        <div></div>
    </footer>
    <div id="snackbar"></div>
</body>

</html>
<?php /**PATH C:\laragon\www\pweb2_laravel_2023_1\resources\views/ProdutoForm.blade.php ENDPATH**/ ?>